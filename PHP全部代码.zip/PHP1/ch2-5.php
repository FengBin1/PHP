<!--202305420615-冯斌-->
<?php
    //
    define("NICKNAME","sunny");
    echo "hello,".NICKNAME."<br/>";
?>