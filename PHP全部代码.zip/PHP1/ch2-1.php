<!--202305420615-冯斌-->
<?php
    $name="hello1";
    $Name="hello2";
    echo $name."<br/>";
    ECHO $Name;
?>