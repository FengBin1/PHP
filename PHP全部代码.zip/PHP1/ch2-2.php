<!--202305420615-冯斌-->
<?php
    echo '<p align="center">我要居中</p>';
    echo "<font size='5'>这是5号字体</font>";
?>