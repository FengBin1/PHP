<!DOCTYPE html>
<html>
<head>
	<mata charset="UTF-8">
		<title><?php echo '这是标题'; ?></title>
		<style>
			body {background-color: <?php echo 'black' ;?>;}
		</style>
		<script>
		alert(<?php echo 10+20; ?>);
		</script>
	</head>
	<body>
		<font color="<?php echo 'white'; ?>">
		<?php echo '<strong>黑马</strong>'; ?>程序员
		</font>
	</body>
</html>