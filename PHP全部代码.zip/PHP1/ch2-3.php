<!--202305420615-冯斌-->
<?php
$name="张三";
echo "Hi,$name<br/>";
echo "Hi,\$name<br/>";
echo 'Hi,$name';
?>
