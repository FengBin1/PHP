<?php
echo '<img src="PHP1/image/01.jpg" width="200" height=s"200"/>';
?>

