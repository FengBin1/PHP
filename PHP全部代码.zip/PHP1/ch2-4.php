<!--202305420615-冯斌-->
<?php
$x=2.5;
if(is_int($x)) echo'$x是整型变量';
if(is_float($x)) echo'$x是浮点型变量';
if(is_string($x)) echo '$x是字串型变量';
if(is_bool($x)) echo'$x是布尔型变量';
?>
