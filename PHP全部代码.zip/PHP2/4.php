<?php
include './a.php';
print_r(get_included_files());
