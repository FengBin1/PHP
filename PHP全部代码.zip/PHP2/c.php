<?php
include './d.php';
