<!--计科21-5--0512---乔伟-->
<?php
if (version_compare(PHP_VERSION, '8.3.9', '<')) {
    exit ('您的PHP版本低于8.3.9，无法运行此脚本！');
}
